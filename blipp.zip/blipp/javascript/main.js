var blipp = require("blippar").blipp;
var scene = blipp.addScene();
    scene.addRequiredAssets(["palette.html", "palette.zip"]);

function tryURL(url){
    try {
        console.log("try", url);
        blipp.overlayHTML('', true, true, url);
    } catch(e){
        console.log("fail", url);
        return;
    }  
};

scene.onShow = function(){
    console.log("I LOVE BLIPPBASIC SO MUCH");
    tryURL("palette.html");
    tryURL("assets/palette.html");
};